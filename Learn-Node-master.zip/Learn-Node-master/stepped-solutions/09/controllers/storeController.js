exports.homePage = (req, res) => {
  res.render('index');
};
